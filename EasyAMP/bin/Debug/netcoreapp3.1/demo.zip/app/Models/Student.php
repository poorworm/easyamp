<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Student
 * 
 * @property int $id
 * @property string|null $name
 * @property string|null $id_card_number
 * @property int|null $xclass_id
 * @property int|null $teacher_id
 * 
 * @property Teacher $teacher
 * @property Xclass $xclass
 * @property Collection|Project[] $projects
 *
 * @package App\Models
 */
class Student extends Model
{
	protected $table = 'student';
	public $timestamps = false;

	protected $casts = [
		'xclass_id' => 'int',
		'teacher_id' => 'int'
	];

	protected $fillable = [
		'name',
		'id_card_number',
		'xclass_id',
		'teacher_id'
	];

	public function teacher()
	{
		return $this->belongsTo(Teacher::class);
	}

	public function xclass()
	{
		return $this->belongsTo(Xclass::class);
	}

	public function projects()
	{
		return $this->belongsToMany(Project::class, 'student_project')
					->withPivot('id');
	}
}
