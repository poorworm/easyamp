<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class AchieveTarget
 * 
 * @property int $id
 * @property string|null $name
 * @property int|null $project_item_id
 * 
 * @property GradeItem $grade_item
 *
 * @package App\Models
 */
class AchieveTarget extends Model
{
	protected $table = 'achieve_target';
	public $timestamps = false;

	protected $casts = [
		'project_item_id' => 'int'
	];

	protected $fillable = [
		'name',
		'project_item_id'
	];

	public function grade_item()
	{
		return $this->belongsTo(GradeItem::class, 'project_item_id');
	}
}
