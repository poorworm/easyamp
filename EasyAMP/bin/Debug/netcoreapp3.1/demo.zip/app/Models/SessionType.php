<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;

/**
 * Class SessionType
 * 
 * @property int $id
 * @property string|null $session_name
 * 
 * @property Collection|ProjectSection[] $project_sections
 *
 * @package App\Models
 */
class SessionType extends Model
{
	protected $table = 'session_type';
	public $timestamps = false;

	protected $fillable = [
		'session_name'
	];

	public function project_sections()
	{
		return $this->hasMany(ProjectSection::class);
	}
}
