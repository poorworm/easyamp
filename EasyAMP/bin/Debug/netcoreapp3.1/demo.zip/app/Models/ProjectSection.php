<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;

/**
 * Class ProjectSection
 * 
 * @property int $id
 * @property int|null $session_type_id
 * @property int|null $project_id
 * 
 * @property Project $project
 * @property SessionType $session_type
 * @property Collection|GradingItem[] $grading_items
 *
 * @package App\Models
 */
class ProjectSection extends Model
{
	protected $table = 'project_section';
	public $timestamps = false;

	protected $casts = [
		'session_type_id' => 'int',
		'project_id' => 'int'
	];

	protected $fillable = [
		'session_type_id',
		'project_id'
	];

	public function project()
	{
		return $this->belongsTo(Project::class);
	}

	public function session_type()
	{
		return $this->belongsTo(SessionType::class);
	}

	public function grading_items()
	{
		return $this->hasMany(GradingItem::class, 'project_session_id');
	}
}
