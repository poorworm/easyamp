<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Project
 * 
 * @property int $id
 * @property string|null $name
 * 
 * @property Collection|ProjectSection[] $project_sections
 * @property Collection|Student[] $students
 *
 * @package App\Models
 */
class Project extends Model
{
	protected $table = 'project';
	public $timestamps = false;

	protected $fillable = [
		'name'
	];

	public function project_sections()
	{
		return $this->hasMany(ProjectSection::class);
	}

	public function students()
	{
		return $this->belongsToMany(Student::class, 'student_project')
					->withPivot('id');
	}
}
