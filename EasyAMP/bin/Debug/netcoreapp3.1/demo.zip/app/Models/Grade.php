<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Grade
 * 
 * @property int $id
 * @property int|null $value
 * @property int|null $sort_order
 * 
 * @property Collection|GradingItem[] $grading_items
 *
 * @package App\Models
 */
class Grade extends Model
{
	protected $table = 'grade';
	public $timestamps = false;

	protected $casts = [
		'value' => 'int',
		'sort_order' => 'int'
	];

	protected $fillable = [
		'value',
		'sort_order'
	];

	public function grading_items()
	{
		return $this->hasMany(GradingItem::class);
	}
}
