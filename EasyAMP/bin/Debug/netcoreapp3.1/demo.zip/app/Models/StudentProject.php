<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class StudentProject
 * 
 * @property int $id
 * @property int|null $student_id
 * @property int|null $project_id
 * 
 * @property Project $project
 * @property Student $student
 *
 * @package App\Models
 */
class StudentProject extends Model
{
	protected $table = 'student_project';
	public $timestamps = false;

	protected $casts = [
		'student_id' => 'int',
		'project_id' => 'int'
	];

	protected $fillable = [
		'student_id',
		'project_id'
	];

	public function project()
	{
		return $this->belongsTo(Project::class);
	}

	public function student()
	{
		return $this->belongsTo(Student::class);
	}
}
