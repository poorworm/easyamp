<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Teacher
 * 
 * @property int $id
 * @property string|null $name
 * 
 * @property Collection|Student[] $students
 *
 * @package App\Models
 */
class Teacher extends Model
{
	protected $table = 'teacher';
	public $timestamps = false;

	protected $fillable = [
		'name'
	];

	public function students()
	{
		return $this->hasMany(Student::class);
	}
}
