<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class GradingItem
 * 
 * @property int $id
 * @property int|null $grade_id
 * @property int|null $grade_item_id
 * @property int|null $project_session_id
 * 
 * @property Grade $grade
 * @property GradeItem $grade_item
 * @property ProjectSection $project_section
 *
 * @package App\Models
 */
class GradingItem extends Model
{
	protected $table = 'grading_item';
	public $timestamps = false;

	protected $casts = [
		'grade_id' => 'int',
		'grade_item_id' => 'int',
		'project_session_id' => 'int'
	];

	protected $fillable = [
		'grade_id',
		'grade_item_id',
		'project_session_id'
	];

	public function grade()
	{
		return $this->belongsTo(Grade::class);
	}

	public function grade_item()
	{
		return $this->belongsTo(GradeItem::class);
	}

	public function project_section()
	{
		return $this->belongsTo(ProjectSection::class, 'project_session_id');
	}
}
