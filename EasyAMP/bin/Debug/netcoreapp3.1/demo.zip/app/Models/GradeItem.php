<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;

/**
 * Class GradeItem
 * 
 * @property int $id
 * @property string|null $name
 * @property int|null $sort_order
 * 
 * @property Collection|AchieveTarget[] $achieve_targets
 * @property Collection|GradingItem[] $grading_items
 *
 * @package App\Models
 */
class GradeItem extends Model
{
	protected $table = 'grade_item';
	public $timestamps = false;

	protected $casts = [
		'sort_order' => 'int'
	];

	protected $fillable = [
		'name',
		'sort_order'
	];

	public function achieve_targets()
	{
		return $this->hasMany(AchieveTarget::class, 'project_item_id');
	}

	public function grading_items()
	{
		return $this->hasMany(GradingItem::class);
	}
}
